//
//  SignUpform.swift
//  PerkBank
//
//  Created by Yin on 23/6/2019.
//  Copyright © 2019 Yin. All rights reserved.
//

import UIKit
import Eureka
import Firebase
import Foundation


class OrderVC: FormViewController  {

    var accountname: String = ""
    var accountnumber: String = ""
    var currency: String = ""
    var amount: Int = 0
    var benficiaryno: String = ""
    var benficiaryname: String = ""
    var benficiarybank: String = ""
    var purpose: String = ""
    var msg: String = ""
    var date: Date? = nil
    var ref: DatabaseReference!
    
    //var ref: DatabaseReference!
    //var charges: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        form +++ Section ("Account Details")
            <<< TextRow(){ row in
                row.tag = "accountname"
                row.title = "Account Name"
                row.placeholder = "Account Name"
            }.onChange({ (row) in self.accountname = row.value != nil ? row.value!: ""})
            
            <<< ActionSheetRow<String>(){ row in
                row.title = "Account Number"
                row.options = ["2-9051-990.F" , "None"]
                row.selectorTitle = "Account Number"
                row.value = ""
            }.onChange({ (row) in self.accountnumber = row.value != nil ? row.value!: ""})
            
            /*<<< TextRow(){ row in
                row.tag = "accountnumber"
                row.title = "Account Number"
                row.placeholder = "Account Number"
            }.onChange({ (row) in self.accountnumber = row.value != nil ? row.value!: ""})*/
            
            +++ Section("Transaction")
            <<< ActionSheetRow<String>(){ row in
                row.title = "Currency"
                row.options = ["Hong Kong Dollar", "US Dollar", "Australian Dollar" , "Canadian Dollar" , "Euro" , "Japanese Yuen" , "New Zealand Dallar" , "Philippine Peso" , "Pound Sterling" , "Renminbi" , "Singapore Dollar" , "Swiss Franc" , "Thai Baht"]
                row.selectorTitle = "Currency"
                row.value = "Hong Kong Dollar"
            }.onChange({ (row) in self.currency = row.value != nil ? row.value!: ""})
            
            <<< IntRow(){ row in
                row.tag = "amount"
                row.title = "Amount"
                row.placeholder = "Amount"
                }.onChange({ (row) in self.amount = row.value!})
            
            +++ Section("Date")
            <<< DateRow(){ row in
                row.title = "Value Date"
                row.tag = "date"
                }.onChange({(row) in self.date = row.value})
                
            /*<<< ActionSheetRow<String>(){ row in
                row.title = "Charges"
                row.options = ["Costs borne by beneficiary" , "Costs borne by payer"]
                row.value = "Costs borne by beneficiary"
                row.selectorTitle = "Charges"
                row.tag = "charges"
                }.onChange({ (row) in self.charges = row.value != nil ? row.value!: ""})*/
        
            +++ Section ("Beneficiary")
            <<< TextRow(){ row in
                row.tag = "Beneficiaryno"
                row.title = "Beneficiary Account Number"
                row.placeholder = "Beneficiary Account Number"
            }.onChange({ (row) in self.benficiaryno = row.value != nil ? row.value!: ""})
            
            <<< TextRow(){ row in
                row.tag = "Beneficiaryname"
                row.title = "Beneficiary Name"
                row.placeholder = "Beneficiary Name"
            }.onChange({ (row) in self.benficiaryname = row.value != nil ? row.value!: ""})
            
            <<< TextRow(){ row in
                row.tag = "Beneficiarybank"
                row.title = "Beneficiary's bank"
                row.placeholder = "Beneficiary's bank"
             }.onChange({ (row) in self.benficiarybank = row.value != nil ? row.value!: ""})
        
            +++ Section ("Extra information(optional)")
            <<< TextRow(){ row in
                row.tag = "purpose"
                row.title = "Payment Purpose"
                row.placeholder = "Payment Purpose"
                }.onChange({ (row) in self.purpose = row.value != nil ? row.value!: ""})
            
            <<< TextRow(){ row in
                row.tag = "msg"
                row.title = "Message to Operation"
                row.placeholder = "Message"
                }.onChange({ (row) in self.msg = row.value != nil ? row.value!: ""})
            
            +++ Section ("Confirm the transaction")
            <<< IntRow(){ row in
                row.tag = "confirm"
                row.title = "Type OTP to confirm order"
                row.placeholder = "Type"
                }.onChange({ (row) in
                    let formatter = DateFormatter()
                    formatter.dateFormat = "yyyy-MM-dd-HH-mm-ss"
                    let date = formatter.string(from: Date())
                    formatter.dateFormat = "yyyy-MM-dd"
                    let dateString = formatter.string(from: self.date!)
                    self.ref = Database.database().reference()
                    var data = ["Account Name":self.accountname,
                                "Account Number":self.accountnumber,
                                "Transaction currency": self.currency ,
                                "Amount":self.amount,
                                "Value Date": dateString as Any,
                                "Beneficiary Account Number":self.benficiaryno,
                                "Beneficiary Name":self.benficiaryname ,
                                "Beneficiary's bank":self.benficiarybank ,
                                "Payment Purpose":self.purpose,
                                "Message to Operation":self.msg]
                    print(data)
                    self.ref.child(date).setValue(data)
                })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    
    
    
}
