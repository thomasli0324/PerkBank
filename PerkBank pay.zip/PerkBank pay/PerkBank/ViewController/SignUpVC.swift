//
//  SignUp.swift
//  PerkBank
//
//  Created by Yin on 22/6/2019.
//  Copyright © 2019 Yin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth


class SignUpVC: UIViewController {

    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    
    @IBAction func onSignUpPressed(_ sender: Any)
    {
        guard let email = txtEmail.text , let password = txtPassword.text else {
            AlertController.showAlert(inViewController: self, title: "Alert", message: "Please fill out all fields.")
            return
        }
        
        Auth.auth().createUser(withEmail: email, password: password){
            
            (user,error) in
            if(user != nil){
                self.performSegue(withIdentifier: "signUpSegue", sender: nil)
            }
            
            if(error != nil){
                AlertController.showAlert(inViewController: self, title: "Alert", message: error!.localizedDescription)
                return
            }
        }
    }
    

}
