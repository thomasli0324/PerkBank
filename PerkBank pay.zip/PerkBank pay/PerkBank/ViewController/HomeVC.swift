//
//  HomeVC.swift
//  PerkBank
//
//  Created by Yin on 22/6/2019.
//  Copyright © 2019 Yin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class HomeVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let email = Auth.auth().currentUser?.email else{
            return
        }
        
    }
    
    @IBAction func onLogoutPressed(_ sender: Any) {
        
        do {
            try Auth.auth().signOut()
            performSegue(withIdentifier: "homeSegue", sender: sender)
        }
        catch{
            print(error)
        }
        
    }
    
    let transition = SlideInTransition()
    @IBAction func didTapMenu(_ sender: UIBarButtonItem) {
        guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuVC") as?
            MenuVC else { return }
        menuViewController.didTapMenuType = { menuType in
            self.transitionToNew(menuType: menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self
        present(menuViewController, animated:true)
    }
    
    
    var topView:UIView?
    func transitionToNew(menuType: MenuType){
        let title = String(describing: menuType).capitalized
        self.title = title
        topView?.removeFromSuperview()
    
        /*switch menuType{
        case .home:
            let view = UIView()
            view.backgroundColor = .yellow
            view.frame = self.view.bounds
            self.view.addSubview(view)
            self.topView = view
            
        case .stock:
            let view = UIView()
            view.frame = self.view.bounds
            self.view.addSubview(view)
            self.topView = view
        case .currency:
            let view = UIView()
            view.frame = self.view.bounds
            self.view.addSubview(view)
            self.topView = view
        case .record:
            let view = UIView()
            view.frame = self.view.bounds
            self.view.addSubview(view)
            self.topView = view
        case .contact:
            let view = UIView()
            view.frame = self.view.bounds
            self.view.addSubview(view)
        }*/
        
    }
    
}

extension HomeVC: UIViewControllerTransitioningDelegate{
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.isPresenting = true
        return transition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.isPresenting = false 
        return transition
    }
}
